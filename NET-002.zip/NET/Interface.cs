using System;
using System.Collections;
using System.Data;
using OutSystems.HubEdition.RuntimePlatform;

namespace OutSystems.NssExtractionFunction {

	public interface IssExtractionFunction {

		/// <summary>
		/// 抽出関数
		/// </summary>
		/// <param name="ssInAccountDefinitionId"></param>
		/// <param name="ssInText"></param>
		/// <param name="ssOutResult"></param>
		/// <param name="ssIsError"></param>
		/// <param name="ssErrorMessage"></param>
		void MssExecuteExtractionFunc(long ssInAccountDefinitionId, string ssInText, out bool ssOutResult, out bool ssIsError, out string ssErrorMessage);

	} // IssExtractionFunction

} // OutSystems.NssExtractionFunction
