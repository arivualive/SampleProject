using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using OutSystems.HubEdition.RuntimePlatform;
using OutSystems.RuntimePublic.Db;

namespace OutSystems.NssExtractionFunction {

	public class CssExtractionFunction: IssExtractionFunction {


        private static void CheckCellsCount(string[] cells, int minimalCount)
        {
            if (cells.Length < minimalCount)
                // Check there is enough cells to verify logic
                throw new ArgumentException(String.Format("There are {0} rows, while there is required to have {1} rows at least", cells.Length, minimalCount));
        }

        /// <summary>
        /// 抽出関数
        /// </summary>
        /// <param name="ssInAccountDefinitionId"></param>
        /// <param name="ssInText"></param>
        /// <param name="ssOutResult"></param>
        /// <param name="ssIsError"></param>
        /// <param name="ssErrorMessage"></param>
        public void MssExecuteExtractionFunc(long ssInAccountDefinitionId, string ssInText, out bool ssOutResult, out bool ssIsError, out string ssErrorMessage) {
			ssOutResult = false;
			ssIsError = false;
			ssErrorMessage = "";

            try
            {
                if (ssInAccountDefinitionId >= 1 && ssInAccountDefinitionId <= 14)
                {
                    //ssOutResult = businessLogic[ssInAccountDefinitionId](ssInText.Split(new char[] { ',' }, StringSplitOptions.None));

                    string[] cells = ssInText.Split(new char[] { ',' }, StringSplitOptions.None);

                    // 1stRow「01」OR「12 」OR「22」
                    if (ssInAccountDefinitionId == 1)
                    {
                        CheckCellsCount(cells, 1);
                        ssOutResult = cells[0].Equals("01") || cells[0].Equals("11") || cells[0].Equals("02");
                    }
                    // 5thRow「売上」 OR 「返品」）OR 6thRow「成功」AND 7thRow NotEqual to「00」	
                    else if (ssInAccountDefinitionId == 2)
                    {
                        CheckCellsCount(cells, 7);
                        ssOutResult = (cells[4].Equals("売上") || cells[4].Equals("返品")) || cells[5].Equals("成功") && !cells[6].Equals("成功");
                    }
                    // 5thRow「売上」 OR 「返品」）OR 6thRow「成功」AND 7thRow NotEqual to「00」	
                    else if (ssInAccountDefinitionId == 3)
                    {
                        CheckCellsCount(cells, 7);
                        ssOutResult = (cells[4].Equals("売上") || cells[4].Equals("返品")) || cells[5].Equals("成功") && !cells[6].Equals("成功");
                    }
                    // 1stRow「1」AND 29thRow NotEqual to「99」
                    else if (ssInAccountDefinitionId == 4)
                    {
                        CheckCellsCount(cells, 30);
                        ssOutResult = cells[0].Equals("1") && !cells[29].Equals("11");
                    }
                    // 4thRow「20」
                    else if (ssInAccountDefinitionId == 5)
                    {
                        CheckCellsCount(cells, 4);
                        ssOutResult = cells[3].Equals("20");
                    }
                    // 14thRow blank「」
                    else if (ssInAccountDefinitionId == 6)
                    {
                        CheckCellsCount(cells, 14);
                        ssOutResult = cells[13].Length == 0;
                    }
                    // 1stRow「2」
                    else if (ssInAccountDefinitionId == 7)
                    {
                        CheckCellsCount(cells, 1);
                        ssOutResult = cells[0].Equals("2");
                    }
                    // 1stRow「1」
                    else if (ssInAccountDefinitionId == 8)
                    {
                        CheckCellsCount(cells, 1);
                        ssOutResult = cells[0].Equals("1");
                    }
                    // 1stRow「6」
                    else if (ssInAccountDefinitionId == 9)
                    {
                        CheckCellsCount(cells, 1);
                        ssOutResult = cells[0].Equals("6");
                    }
                    // 1stRow「1」
                    else if (ssInAccountDefinitionId == 10)
                    {
                        CheckCellsCount(cells, 1);
                        ssOutResult = cells[0].Equals("1");
                    }
                    // 4thRow NotEqual to「0」
                    else if (ssInAccountDefinitionId == 11)
                    {
                        CheckCellsCount(cells, 4);
                        ssOutResult = !cells[3].Equals("0");
                    }
                    // 1stLetter「2」AND 112ndletter「0」
                    else if (ssInAccountDefinitionId == 12)
                    {
                        CheckCellsCount(cells, 1);
                        string j = String.Join(",", cells);
                        if (j.Length > 111)
                        {
                            ssOutResult = j[0] == '2' && j[111] == '0';
                        }
                        else
                            ssOutResult = false;
                    }
                    // 1stRow NotEqual to「通番」OR NotEqual to 「」blank AND  3rdRow AND 5thRow blank「」
                    else if (ssInAccountDefinitionId == 13)
                    {
                        CheckCellsCount(cells, 5);
                        ssOutResult = (!cells[0].Equals("通番") && cells[0].Length != 0) && cells[2].Length == 0 && cells[4].Length == 0;
                    }
                    // 3rdRow「カード決済金額」OR「ワイジェイカード・PayPayカード決済金額」OR「ポイント利用料」OR「モールクーポン利用料」
                    else if (ssInAccountDefinitionId == 14)
                    {
                        CheckCellsCount(cells, 3);
                        ssOutResult = cells[2].Equals("カード決済金額") || cells[2].Equals("ワイジェイカード・PayPayカード決済金額") || cells[2].Equals("ポイント利用料") || cells[2].Equals("モールクーポン利用料");
                    }
                }
                else
                    throw new ArgumentOutOfRangeException("ssInAccountDefinitionId", ssInAccountDefinitionId, "id should be in range 1-14 inclusive");
            }
            catch (Exception e)
            {
                //加工処理にてエラー発生した場合、エラーフラグを立て、エラーメッセージを返す
                ssIsError = true;
                ssErrorMessage = e.Message;
            }

        } // MssExecuteExtractionFunc


	} // CssExtractionFunction

} // OutSystems.NssExtractionFunction

