﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class HomeController : Controller
    {

        private readonly ILogger<HomeController> _logger;

        public string IdValue { get; set; }
        public string TextValue { get; set; }
        public string OutputValue { get; set; }

        public bool IsError { get; set; }
        public string ErrorMessage { get; set; }

        private Dictionary<String, Func<string[], bool>> businessLogic = new Dictionary<string, Func<string[], bool>>()
        {
            // 1stRow「01」OR「12 」OR「22」
            ["1"] = (cells) => { return cells[0].Equals("01") || cells[0].Equals("11") || cells[0].Equals("02"); },
            // 5thRow「売上」 OR 「返品」）OR 6thRow「成功」AND 7thRow NotEqual to「00」	
            ["2"] = (cells) => { return (cells[4].Equals("売上" )|| cells[4].Equals("返品")) || cells[5].Equals("成功") && !cells[6].Equals("成功"); },
            // 5thRow「売上」 OR 「返品」）OR 6thRow「成功」AND 7thRow NotEqual to「00」	
            ["3"] = (cells) => { return (cells[4].Equals("売上") || cells[4].Equals("返品")) || cells[5].Equals("成功") && !cells[6].Equals("成功"); },
            // 1stRow「1」AND 29thRow NotEqual to「99」
            ["4"] = (cells) => { return cells[0].Equals("1") && !cells[29].Equals("11"); },
            // 4thRow「20」
            ["5"] = (cells) => { return cells[3].Equals("20"); },
            // 14thRow blank「」
            ["6"] = (cells) => { return cells[13].Length==0; },
            // 1stRow「2」
            ["7"] = (cells) => { return cells[0].Equals("2"); },
            // 1stRow「1」
            ["8"] = (cells) => { return cells[0].Equals("1"); },
            // 1stRow「6」
            ["9"] = (cells) => { return cells[0].Equals("6"); },
            // 1stRow「1」
            ["10"] = (cells) => { return cells[0].Equals("1"); },
            // 4thRow NotEqual to「0」
            ["11"] = (cells) => { return !cells[3].Equals("0"); },
            // 1stLetter「2」AND 112ndletter「0」
            ["12"] = (cells) => { string j = String.Join(",", cells);  if (j.Length > 111) { return j[0] == '2' && j[111] == '0'; } else return false; },
            // 1stRow NotEqual to「通番」OR NotEqual to 「」blank AND  3rdRow AND 5thRow blank「」
            ["13"] = (cells) => { return (!cells[0].Equals("通番") && cells[0].Length != 0) && cells[2].Length== 0 && cells[4].Length == 0; },
            // 3rdRow「カード決済金額」OR「ワイジェイカード・PayPayカード決済金額」OR「ポイント利用料」OR「モールクーポン利用料」
            ["14"] = (cells) => { return cells[2].Equals("カード決済金額") || cells[2].Equals("ワイジェイカード・PayPayカード決済金額") || cells[2].Equals("ポイント利用料") || cells[2].Equals("モールクーポン利用料"); }
        };

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;

            IsError = false;
            ErrorMessage = null;

        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(string id, string text, string output)
        {
            ViewBag.IdValue = id;
            ViewBag.TextValue = text;
            bool r = false;
           
            try
            {
                string[] cells = text.Split(new char[] { ',' }, StringSplitOptions.TrimEntries);
                r = businessLogic[id](cells);
                string calcOutput = r.ToString();
                ViewBag.OutputResultValue = calcOutput;
                ViewBag.IsError = false;
                ViewBag.ErrorMessage = null;
            }
            catch(Exception ex)
            {
                ViewBag.IsError = true;
                ViewBag.ErrorMessage = ex.Message;
            }
            return View();
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}