using System;
using System.Collections;
using System.Data;
using OutSystems.HubEdition.RuntimePlatform;
using OutSystems.RuntimePublic.Db;

namespace OutSystems.NssExtractionFunction {

	public class CssExtractionFunction: IssExtractionFunction {

		/// <summary>
		/// 抽出関数
		/// </summary>
		/// <param name="ssInAccountDefinitionId"></param>
		/// <param name="ssInText"></param>
		/// <param name="ssOutResult"></param>
		/// <param name="ssIsError"></param>
		/// <param name="ssErrorMessage"></param>
		public void MssExecuteExtractionFunc(long ssInAccountDefinitionId, string ssInText, out bool ssOutResult, out bool ssIsError, out string ssErrorMessage) {
			ssOutResult = false;
			ssIsError = false;
			ssErrorMessage = "";
			// TODO: Write implementation for action
		} // MssExecuteExtractionFunc

	} // CssExtractionFunction

} // OutSystems.NssExtractionFunction

