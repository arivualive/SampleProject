﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public string IdValue { get; set; }
        public string TextValue { get; set; }
        public string OutputValue { get; set; }

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(string id, string text, string output)
        {
            ViewBag.IdValue = id;
            ViewBag.TextValue = text;
            bool r = false;
            string[] cells = text.Split(new char[] { ',' }, StringSplitOptions.TrimEntries);

            if (id.Equals("1"))
                if (cells[3].Equals("10"))
                    r = true;

            if (id.Equals("2"))
                if (cells[0].Equals("2022"))
                    r = true;

            if (id.Equals("3"))
                if (cells[4].Equals("333"))
                    r = true;

            if (id.Equals("4"))
                if (cells[3].Equals("AAA"))
                    r = true;

            if (id.Equals("5"))
                if (cells[3].Equals("14"))
                    r = true;

            if (id.Equals("6"))
                if (cells[2].Equals("15"))
                    r = true;

            if (id.Equals("7"))
                if (cells[3].Equals("16"))
                    r = true;

            if (id.Equals("8"))
                if (cells[1].Length>=30)
                    if (cells[0][0]=='A' && cells[0][29] == 'G')
                    r = true;

            if (id.Equals("9"))
                if (cells[0].Equals("18"))
                    r = true;

            if (id.Equals("10"))
                if (cells[3].Equals("19"))
                    r = true;

            if (id.Equals("11"))
                if (cells[3].Equals("20"))
                    r = true;

            if (id.Equals("12"))
                if (cells[1].Equals("21"))
                    r = true;

            if (id.Equals("13"))
                if (cells[3].Equals("22"))
                    r = true;

            if (id.Equals("14"))
                if (cells[5].Equals("CCCCCC"))
                    r = true;

            string calcOutput = r.ToString();

            ViewBag.OutputResultValue = calcOutput;
            return View();
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}