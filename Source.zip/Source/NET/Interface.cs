using System;
using System.Collections;
using System.Data;
using OutSystems.HubEdition.RuntimePlatform;

namespace OutSystems.NssExecuteProcessing {

	public interface IssExecuteProcessing {

		/// <summary>
		/// 
		/// </summary>
		/// <param name="ssFuncName"></param>
		/// <param name="ssInText">1行分のデータ（固定長orカンマ区切り）</param>
		/// <param name="ssParam1"></param>
		/// <param name="ssParam2"></param>
		/// <param name="ssParam3"></param>
		/// <param name="ssParam4"></param>
		/// <param name="ssParam5"></param>
		/// <param name="ssParamCount"></param>
		/// <param name="ssOutText"></param>
		/// <param name="ssIsError"></param>
		/// <param name="ssErrorMessage"></param>
		void MssExecuteProcess(string ssFuncName, string ssInText, string ssParam1, string ssParam2, string ssParam3, string ssParam4, string ssParam5, int ssParamCount, out string ssOutText, out bool ssIsError, out string ssErrorMessage);

	} // IssExecuteProcessing

} // OutSystems.NssExecuteProcessing
