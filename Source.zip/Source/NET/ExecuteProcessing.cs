using System;
using OutSystems.HubEdition.RuntimePlatform;
using OutSystems.RuntimePublic.Db;
using System.Collections.Generic;

namespace OutSystems.NssExecuteProcessing {

	public class CssExecuteProcessing: IssExecuteProcessing {

		/// <summary>
		/// OutSystemsから呼ばれる、加工処理を実行するメソッド。
		/// </summary>
		/// <param name="ssFuncName">加工関数ID</param>
		/// <param name="ssInText">加工元文字列</param>
		/// <param name="ssParam1~5">加工に用いるパラメタ</param>
		/// <param name="ssOutText">加工結果文字列</param>
		/// <param name="ssIsError">エラーフラグ</param>
		/// <param name="ssErrorMessage">エラーメッセージ</param>
		public void MssExecuteProcess(string ssFuncName, string ssInText, string ssParam1, string ssParam2, string ssParam3, string ssParam4, string ssParam5, int ssParamCount, out string ssOutText, out bool ssIsError, out string ssErrorMessage) {
			
			//引数のパラメータを配列に格納
			string[] StringArray = {ssParam1,ssParam2,ssParam3,ssParam4,ssParam5}; 

			//ローカル変数定義
			Process Funcname;

			//out変数初期化
			ssIsError = false;
			ssOutText = "";
			ssErrorMessage = "";

			try{
				//引数名をenum型に型変換
				bool IsExistProcess = Enum.TryParse(ssFuncName,out Funcname);
				if(IsExistProcess == false){
					throw new Exception("引数と一致する加工処理が存在しません。");
				}

				//実行する加工処理クラスのインスタンスを作成し、加工処理メソッドを実行
				ProcessFactory Ps = new ProcessFactory();
				ProcessInterface Pi = Ps.create(Funcname);
				ssOutText = Pi.exec(ssInText, ssParamCount, StringArray);

			}catch(Exception e){
				//加工処理にてエラー発生した場合、エラーフラグを立て、エラーメッセージを返す
				ssIsError = true;
				ssErrorMessage = e.Message;
			}
			
		} // MssExecuteProcess

	} // CssExecuteProcessing

} // OutSystems.NssExecuteProcessing

