using System;

namespace OutSystems.NssExecuteProcessing {

	//ConditionJudgment:条件判定(列指定)
    public class ConditionJudgment:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){
            // 共通処理
            Common Com = new Common();
            long param1;
            long param2;
            string selectColumnText1;
            string selectColumnText2;
            string outText;
            try
            {
                //データの存在チェック（入力データの内容チェック&パラメータ数チェック）
                Com.ExistsDataCheck(inText, paramCount, param);
                // 数値変換
                param1 = Com.ConvertNumeric(param[0]); // 参照列番号
                param2 = Com.ConvertNumeric(param[2]); // 参照列番号
                // 指定位置文字取得
                selectColumnText1 = Com.GetSelectColumnString(inText, param1);
                selectColumnText2 = Com.GetSelectColumnString(inText, param2);
            }
            catch (Exception ex)
            {
                throw;
            }
            try
            {
                // パラメータ1とパラメータ2が等しいか確認
                if (selectColumnText1 == param[1])
                {
                    outText = selectColumnText2;
                }
                else
                {
                    outText = "";
                }
                return outText;
            }
            catch 
            {
                throw new Exception("条件判定に失敗しました。");
            }
        }
    }

}