using System;

namespace OutSystems.NssExecuteProcessing {
    
	//ConcatString：文字列削除処理
	//param1:削除対象文字列
    public class DeleteString:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){

            return inText.Replace(param[0],"");
            
        }
    }

}