using System;
using System.Collections;
using System.Data;

namespace OutSystems.NssExecuteProcessing {

	//CommonTest
    public class CommonTest:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){
            // 共通処理
            Common Com = new Common();

            //int param1;
            //int param2;
            //int param3;
            string outText = "";

            try
            {
                // パラメータ数チェック
                Com.ParamCntCheck(param, 3);

                // 数値変換
                //lParam1 = Com.ConvertNumeric(param[0]);

                //param1 = Com.IsNumeric(param[0]); // 参照列番号
                //param2 = Com.IsNumeric(param[1]); // 開始位置
                //param3 = Com.IsNumeric(param[2]); // 文字数

                //outText = Com.GetSelectColumnString(inText, param1);

            }
            catch (Exception ex)
            {
                throw;
            }

            try
            {
                // // 指定位置文字取得
                // string selectColumnText = Com.GetSelectColumnString(inText, param1);

                // // 文字数チェック
                // Com.CheckLength(selectColumnText, param2, param3);    

                // // 文字切り取り
                // string outText = Com.SubstringSelectPosition(selectColumnText, param2, param3);
                
                //string outText = Com.ComTest();

                //string outText = "p1:" + param1 + " p2:" + param2 + " p3:" + param3;

                return outText;
            }
            catch 
            {
                throw new Exception("文字列の抽出に失敗しました。");
            }
        }
    }

}