using System;

namespace OutSystems.NssExecuteProcessing {

	//ConcatColumnAndString:文字列連結(列＋文字)(列指定)
    public class ConcatColumnAndString:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){
            // 共通処理
            Common Com = new Common();
            long param1;
            string selectColumnText1;
            string outText;
            try
            {
                //データの存在チェック（入力データの内容チェック&パラメータ数チェック）
                Com.ExistsDataCheck(inText, paramCount, param);
                // 数値変換
                param1 = Com.ConvertNumeric(param[0]); // 参照列番号
                // 指定位置文字取得
                selectColumnText1 = Com.GetSelectColumnString(inText, param1);
            }
            catch (Exception ex)
            {
                throw;
            }
            try
            {
                // 文字連結
                outText = selectColumnText1 + param[1];
                return outText;
            }
            catch 
            {
                throw new Exception("文字列連結(列＋文字)に失敗しました。");
            }
        }
    }

}