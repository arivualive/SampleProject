using System;

namespace OutSystems.NssExecuteProcessing {

	//SubstringSelectColumn:文字列抽出(列指定)
    public class SubstringSelectColumn:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){
            // 共通処理
            Common Com = new Common();
            try
            {
                //データの存在チェック（入力データの内容チェック&パラメータ数チェック）
                Com.ExistsDataCheck(inText, paramCount, param);
                // 数値変換
                long param1 = Com.ConvertNumeric(param[0]); // 参照列番号
                long param2 = Com.ConvertNumeric(param[1]); // 開始位置
                long param3 = Com.ConvertNumeric(param[2]); // 文字数
                // 指定位置文字取得
                string selectColumnText = Com.GetSelectColumnString(inText, param1);
                // 文字数チェック
                Com.CheckLength(selectColumnText, param2, param3);    
                // 文字切り取り
                string outText = Com.SubstringSelectPosition(selectColumnText, (int)param2, (int)param3);
                return outText;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }

}