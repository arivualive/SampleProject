using System;

namespace OutSystems.NssExecuteProcessing {

	//RemoveStringSelectPosition:指定文字列除去(文字位置指定)
    public class RemoveStringSelectPosition:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){
            // 共通処理
            Common Com = new Common();
            long param1;
            long param2;
            string selectPositionText1;
            string outText;
            try
            {
                //データの存在チェック（入力データの内容チェック&パラメータ数チェック）
                Com.ExistsDataCheck(inText, paramCount, param);
                // 数値変換
                param1 = Com.ConvertNumeric(param[0]); // 開始位置
                param2 = Com.ConvertNumeric(param[1]); // 文字数
                // 文字数チェック
                Com.CheckLength(inText, param1, param2);    
                // 文字切り取り
                selectPositionText1 = Com.SubstringSelectPosition(inText, (int)param1, (int)param2);
            }
            catch (Exception ex)
            {
                throw;
            }
            try
            {
                // 文字列除去
                outText = selectPositionText1.Replace(param[2], "");
                return outText;
            }
            catch 
            {
                throw new Exception("文字列除去に失敗しました。");
            }
        }
    }

}