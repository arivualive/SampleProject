using System;

namespace OutSystems.NssExecuteProcessing {

	//ConcatString:文字列連結処理
    public class ConcatString:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){
            ///TODO:処理の実装
            throw new Exception("処理エラーa");
            //return "文字列連結処理";
        }
    }

}