using System;

namespace OutSystems.NssExecuteProcessing {

	//RemoveFrontZeroSelectColumn:前ゼロ除去(列指定)
    public class RemoveFrontZeroSelectColumn:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){
            // 共通処理
            Common Com = new Common();
            long param1;
            string selectColumnText1;
            string outText;
            try
            {
                //データの存在チェック（入力データの内容チェック&パラメータ数チェック）
                Com.ExistsDataCheck(inText, paramCount, param);
                // 数値変換
                param1 = Com.ConvertNumeric(param[0]); // 参照列番号
                // 指定位置文字取得
                selectColumnText1 = Com.GetSelectColumnString(inText, param1);
            }
            catch (Exception ex)
            {
                throw;
            }
            try
            {
                // 前ゼロ除去
                outText = selectColumnText1.TrimStart('0');
                return outText;
            }
            catch 
            {
                throw new Exception("前ゼロ除去に失敗しました。");
            }
        }
    }

}