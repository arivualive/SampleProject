using System;
using System.Collections;
using System.Data;

namespace OutSystems.NssExecuteProcessing {

	//加工処理実行クラスのインターフェース
    public interface ProcessInterface{
        string exec(string inText, int paramCount, params string[] param);
    }

}