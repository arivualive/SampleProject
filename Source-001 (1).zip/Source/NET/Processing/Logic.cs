﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace OutSystems.NssExecuteProcessing
{
    class Logic : ProcessInterface
    {
        
        private static void CheckCellsCount(string[] cells, int minimalCount)
        {
            if (cells.Length < minimalCount)
                throw new ArgumentException(String.Format("There are {0} rows, while there is required to have {1} rows at least", cells.Length, minimalCount));
        }

        private Dictionary<long, Func<string[], bool>> businessLogic = new Dictionary<long, Func<string[], bool>>()
        {
            // 1stRow「01」OR「12 」OR「22」
            [1] = (cells) => { Logic.CheckCellsCount(cells, 1); return cells[0].Equals("01") || cells[0].Equals("11") || cells[0].Equals("02"); },
            // 5thRow「売上」 OR 「返品」）OR 6thRow「成功」AND 7thRow NotEqual to「00」	
            [2] = (cells) => { Logic.CheckCellsCount(cells, 7);  return (cells[4].Equals("売上") || cells[4].Equals("返品")) || cells[5].Equals("成功") && !cells[6].Equals("成功"); },
            // 5thRow「売上」 OR 「返品」）OR 6thRow「成功」AND 7thRow NotEqual to「00」	
            [3] = (cells) => { Logic.CheckCellsCount(cells, 7);  return (cells[4].Equals("売上") || cells[4].Equals("返品")) || cells[5].Equals("成功") && !cells[6].Equals("成功"); },
            // 1stRow「1」AND 29thRow NotEqual to「99」
            [4] = (cells) => { Logic.CheckCellsCount(cells, 30);  return cells[0].Equals("1") && !cells[29].Equals("11"); },
            // 4thRow「20」
            [5] = (cells) => { Logic.CheckCellsCount(cells, 4);  return cells[3].Equals("20"); },
            // 14thRow blank「」
            [6] = (cells) => { Logic.CheckCellsCount(cells, 14);  return cells[13].Length == 0; },
            // 1stRow「2」
            [7] = (cells) => { Logic.CheckCellsCount(cells, 1);  return cells[0].Equals("2"); },
            // 1stRow「1」
            [8] = (cells) => { Logic.CheckCellsCount(cells, 1);  return cells[0].Equals("1"); },
            // 1stRow「6」
            [9] = (cells) => { Logic.CheckCellsCount(cells, 1);  return cells[0].Equals("6"); },
            // 1stRow「1」
            [10] = (cells) => { Logic.CheckCellsCount(cells, 1);  return cells[0].Equals("1"); },
            // 4thRow NotEqual to「0」
            [11] = (cells) => { Logic.CheckCellsCount(cells, 4);  return !cells[3].Equals("0"); },
            // 1stLetter「2」AND 112ndletter「0」
            [12] = (cells) => { Logic.CheckCellsCount(cells, 1);  string j = String.Join(",", cells); if (j.Length > 111) { return j[0] == '2' && j[111] == '0'; } else return false; },
            // 1stRow NotEqual to「通番」OR NotEqual to 「」blank AND  3rdRow AND 5thRow blank「」
            [13] = (cells) => { Logic.CheckCellsCount(cells, 5);  return (!cells[0].Equals("通番") && cells[0].Length != 0) && cells[2].Length == 0 && cells[4].Length == 0; },
            // 3rdRow「カード決済金額」OR「ワイジェイカード・PayPayカード決済金額」OR「ポイント利用料」OR「モールクーポン利用料」
            [14] = (cells) => { Logic.CheckCellsCount(cells, 3); return cells[2].Equals("カード決済金額") || cells[2].Equals("ワイジェイカード・PayPayカード決済金額") || cells[2].Equals("ポイント利用料") || cells[2].Equals("モールクーポン利用料"); }

        };
        //Logic: Check string for certain conditions
        //param1: id
        public string exec(string inText, int paramCount, params string[] param)
        {
            Common Com = new Common();
            long id = Com.ConvertNumeric(param[0]);
            bool checkResult = false;

            if (id >= 1 && id <= 14)
                checkResult = businessLogic[id](inText.Split(new char[] { ',' }, StringSplitOptions.None));
            else
                throw new ArgumentOutOfRangeException("id", id, "id should be in range 1-14 inclusive");

            return checkResult.ToString().ToUpperInvariant();
        }
    }
}



 
