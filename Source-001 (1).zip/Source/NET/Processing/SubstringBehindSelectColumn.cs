using System;

namespace OutSystems.NssExecuteProcessing {

	//SubstringBehindSelectColumn:指定文字より後から取得(列指定)
    public class SubstringBehindSelectColumn:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){
            // 共通処理
            Common Com = new Common();
            long param1;
            string selectColumnText1;
            string outText;
            try
            {
                //データの存在チェック（入力データの内容チェック&パラメータ数チェック）
                Com.ExistsDataCheck(inText, paramCount, param);
                // 数値変換
                param1 = Com.ConvertNumeric(param[0]); // 参照列番号
                // 指定位置文字取得
                selectColumnText1 = Com.GetSelectColumnString(inText, param1);
            }
            catch (Exception ex)
            {
                throw;
            }
            try
            {
                // 指定文字より後ろから取得（Substring(開始位置, 長さ(無い場合は最後まで))）
                outText = selectColumnText1.Substring(selectColumnText1.LastIndexOf(param[1]) + 1 );//指定文字を後方から検索し開始位置を取得　指定文字を含まないため開始文字＋1
                return outText;
            }
            catch 
            {
                throw new Exception("指定文字より後ろからの取得に失敗しました。");
            }
        }
    }

}