using System;

namespace OutSystems.NssExecuteProcessing {

	//ConvertStringTryumph21:文字変換（トライアンフ21）(列指定)
    public class ConvertStringTryumph21:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){
            // 共通処理
            Common Com = new Common();
            long param1;
            long param2;
            string selectColumnText1;
            string selectColumnText2;
            string selectColumnText3;
            string outText;
            try
            {
                //データの存在チェック（入力データの内容チェック&パラメータ数チェック）
                Com.ExistsDataCheck(inText, paramCount, param);
                // 数値変換
                param1 = Com.ConvertNumeric(param[0]); // 参照列番号
                param2 = Com.ConvertNumeric(param[1]); // 参照列番号
                // 指定位置文字取得
                selectColumnText1 = Com.GetSelectColumnString(inText, param1);
                selectColumnText2 = Com.GetSelectColumnString(inText, param2);
            }
            catch (Exception ex)
            {
                throw;
            }
            try
            {
                // 文字変換
                selectColumnText3 = selectColumnText2.Substring(selectColumnText2.Length - 3);
                outText = selectColumnText1 + "-" + selectColumnText3;
                return outText;
            }
            catch 
            {
                throw new Exception("文字変換（トライアンフ21）に失敗しました。");
            }
        }
    }

}