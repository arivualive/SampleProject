using System;
using System.Text.RegularExpressions;

namespace OutSystems.NssExecuteProcessing {
    
    // 共通関数
    public class Common{
		
        // 数値変換
        public long ConvertNumeric(string inParam){
            string message = "";
            try
            {
                long outParam;
                if (string.IsNullOrWhiteSpace(inParam))
                {
                    // nullもしくは空もしくは空白である
                    message = ":パラメータがありません。";
                    throw new Exception("");
                }
                // 全角数字を半角数字に変換する
                string sInParam = Regex.Replace(inParam, "[０-９]", delegate(Match m) {
                    char ch = (char)('0' + (m.Value[0] - '０'));
                    return ch.ToString();
                });

                // 数値変換（long型に変換）
                if (Int64.TryParse(sInParam, out outParam))
                {
                    // 数値変換出来たらoutParamに数値が入る 
                    return outParam;
                }
                else
                {
                    // 変換できなかった場合
                    message = ":数値ではありません。";
                    throw new Exception("");
                }
            } 
            catch
            {
                throw new Exception("数値変換に失敗しました。" + message );
            }
        }

        // 指定位置文字取得
        public string GetSelectColumnString(string inText, long param1){
            string message = "";
            try
            {
                if(param1 <= 0 )
                {
                    message = ":パラメータの値が不正です。";
                    throw new Exception("");
                }
                // タブ区切りで配列に格納する
                string[] arr =  inText.Split('\t');
                if(arr.Length < param1){message = ":入力データの個数を超えています。";}
                return arr[param1-1];
            }
            catch
            {
                throw new Exception("指定位置の文字列抽出に失敗しました。" + message);
            }
        }

        // 文字切り取り
        public string SubstringSelectPosition(string inText, int param1, int param2){
            string message = "";
            try
            {
                if(param1 < 0 || param2 <= 0 )
                {
                    message = ":パラメータの値が不正です。";
                    throw new Exception("");
                }
                // 文字切り取り
                string outText = inText.Substring(param1-1, param2);
                return outText;
            }
            catch
            {
                throw new Exception("文字列の切り取りに失敗しました。" + message);
            }
        }

        // 文字数チェック
        // 文字を切り取る際に入力データよりもパラメータの数値が超えていないか確認
        public bool CheckLength(string inText, long param1, long param2){
            try
            {
                int lenInText = inText.Length;
                if(param1 < 0 || param2 < 0 )
                {
                    throw new Exception("パラメータの値が不正です。");
                }
                if (lenInText < param1 ) // 入力データ ＜ 開始位置
                {
                    throw new Exception("開始位置が対象の文字数を超えています。");
                }
                if (lenInText < param2 ) // 入力データ ＜ 文字数
                {
                    throw new Exception("指定の文字数が対象の文字数を超えています。");
                }
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        // パラメータ数チェック
        // 各パラメータにデータが入っているか、余分なデータが入っていないか確認
        public bool ParamCntCheck(string[] param, int paramCnt){
            string message = "";
            try
            {
                // パラメータ数0の場合
                if(paramCnt == 0)
                {
                    for (int iCnt = 0; iCnt < 5; iCnt++)
                    {
                        if(param[iCnt].Length != 0)
                        {
                            message = ":使用しないパラメータにデータが含まれています。";
                            throw new Exception("");
                        }
                    }
                    return true;
                }
                //パラメータが足りてない
                for (int i = 0; i <= paramCnt-1; i++)
                {
                    if(param[i].Length <= 0)
                    {
                        message = ":パラメータにデータが足りていません。";
                        throw new Exception("");
                    }
                }
                //パラメータが多い
                for (int j = paramCnt; j < 5; j++)
                {
                    if(param[j].Length != 0)
                    {
                        message = ":使用しないパラメータにデータが含まれています。";
                        throw new Exception("");
                    }
                }
                return true;
            }
            catch
            {
                throw new Exception("パラメータ数チェックに失敗しました。" + message);
            }
        }

        // 入力データの内容チェック
        public bool InTextDataCheck(string inText){
            try
            {
                // 入力データが存在するか確認
                if (string.IsNullOrWhiteSpace(inText))
                {
                    // nullもしくは空もしくは空白である
                    throw new Exception("入力データがありません。");
                }
                // 改行コードCRLF 垂直タブ 改ページが無いか確認
                if(inText.IndexOf("\r\n") > -1 || inText.IndexOf("\r") > -1 || inText.IndexOf("\n") > -1 || inText.IndexOf("\v") > -1 || inText.IndexOf("\f") > -1 )
                {
                    throw new Exception("不正な制御文字が含まれています。");
                }
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        // データの存在チェック（入力データの内容チェック&パラメータ数チェック）
        public bool ExistsDataCheck(string inText, int paramCount, string[] param){
            try
            {
                // 入力データの内容チェック
                InTextDataCheck(inText);
                // パラメータ数チェック
                ConvertNumeric(paramCount.ToString());
                ParamCntCheck(param, paramCount);
                return true;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

    }
}