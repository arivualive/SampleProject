using System;

namespace OutSystems.NssExecuteProcessing {

	//SubstringBehindSelectPosition:指定文字より後から取得(文字位置指定)
    public class SubstringBehindSelectPosition:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){
            // 共通処理
            Common Com = new Common();
            long param1;
            long param2;
            string selectPositionText1;
            string outText;
            try
            {
                //データの存在チェック（入力データの内容チェック&パラメータ数チェック）
                Com.ExistsDataCheck(inText, paramCount, param);
                // 数値変換
                param1 = Com.ConvertNumeric(param[0]); // 開始位置
                param2 = Com.ConvertNumeric(param[1]); // 文字数
                // 文字数チェック
                Com.CheckLength(inText, param1, param2);    
                // 文字切り取り
                selectPositionText1 = Com.SubstringSelectPosition(inText, (int)param1, (int)param2);
            }
            catch (Exception ex)
            {
                throw;
            }
            try
            {
                // 指定文字より後ろから取得（Substring(開始位置, 長さ(無い場合は最後まで))）
                outText = selectPositionText1.Substring(selectPositionText1.LastIndexOf(param[2]) + 1 );//指定文字を後方から検索し開始位置を取得　指定文字を含まないため開始文字＋1
                return outText;
            }
            catch 
            {
                throw new Exception("指定文字より後ろからの取得に失敗しました。");
            }
        }
    }

}