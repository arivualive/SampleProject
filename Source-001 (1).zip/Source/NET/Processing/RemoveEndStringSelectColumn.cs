using System;

namespace OutSystems.NssExecuteProcessing {

	//RemoveEndStringSelectColumn:末尾除去(列指定)
    public class RemoveEndStringSelectColumn:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){
            // 共通処理
            Common Com = new Common();
            long param1;
            long param2;
            long param3;
            string selectColumnText1;
            string outText;
            try
            {
                //データの存在チェック（入力データの内容チェック&パラメータ数チェック）
                Com.ExistsDataCheck(inText, paramCount, param);
                // 数値変換
                param1 = Com.ConvertNumeric(param[0]); // 参照列番号
                param2 = Com.ConvertNumeric(param[1]); // 桁数
                // 指定位置文字取得
                selectColumnText1 = Com.GetSelectColumnString(inText, param1);
                if (selectColumnText1.Length < param2)
                {
                    throw new Exception("桁数が対象の文字数を超えています。");
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            try
            {
                // 指定文字の長さから桁数を引き開始位置を取得する。
                param3 = selectColumnText1.Length - param2;
                // 末尾除去
                outText = selectColumnText1.Remove((int)param3); //param3（開始位置）から最後まで削除
                return outText;
            }
            catch 
            {
                throw new Exception("末尾除去に失敗しました。");
            }
        }
    }

}