using System;

namespace OutSystems.NssExecuteProcessing {

	//JudgmentNumericAriba:数値判定（Ariba(日東電工)）(列指定)
    public class JudgmentNumericAriba:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){
            // 共通処理
            Common Com = new Common();
            long param1;
            string selectColumnText1;
            string outText;
            int iParam;
            try
            {
                //データの存在チェック（入力データの内容チェック&パラメータ数チェック）
                Com.ExistsDataCheck(inText, paramCount, param);
                // 数値変換
                param1 = Com.ConvertNumeric(param[0]); // 参照列番号
                // 指定位置文字取得
                selectColumnText1 = Com.GetSelectColumnString(inText, param1);               
            }
            catch (Exception ex)
            {
                throw;
            }
            try
            {
                // 数値判定
                if (int.TryParse(selectColumnText1, out iParam))
                {
                    outText = selectColumnText1;
                }
                else
                {
                    //数字ではありません。
                    outText = "";
                }
                return outText;
            }
            catch 
            {
                throw new Exception("数値判定（Ariba(日東電工)）に失敗しました。");
            }
        }
    }

}