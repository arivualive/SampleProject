using System;

namespace OutSystems.NssExecuteProcessing {

	//InputFixedValue:固定値入力
    public class InputFixedValue:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){
            // 共通処理
            Common Com = new Common();
            try
            {
                //データの存在チェック（入力データの内容チェック&パラメータ数チェック）
                Com.ExistsDataCheck(inText, paramCount, param);
                return param[0];
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }

}