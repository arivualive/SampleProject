using System;

namespace OutSystems.NssExecuteProcessing {

	//RemoveEndStringSelectPosition:末尾除去(文字位置指定)
    public class RemoveEndStringSelectPosition:ProcessInterface{
		
        public string exec(string inText, int paramCount, params string[] param){
            // 共通処理
            Common Com = new Common();
            long param1;
            long param2;
            long param3;
            long param4;
            string selectPositionText1;
            string outText;

            try
            {
                //データの存在チェック（入力データの内容チェック&パラメータ数チェック）
                Com.ExistsDataCheck(inText, paramCount, param);

                // 数値変換
                param1 = Com.ConvertNumeric(param[0]); // 開始位置
                param2 = Com.ConvertNumeric(param[1]); // 文字数
                param3 = Com.ConvertNumeric(param[2]); // 桁数
                // 文字数チェック
                Com.CheckLength(inText, param1, param2);    
                // 文字切り取り
                selectPositionText1 = Com.SubstringSelectPosition(inText, (int)param1, (int)param2);

                if (selectPositionText1.Length < param3)
                {
                    throw new Exception("桁数が対象の文字数を超えています。");
                }
            }
            catch (Exception ex)
            {
                throw;
            }

            try
            {
                // 指定文字の長さから桁数を引き開始位置を取得する。
                param4 = selectPositionText1.Length - param3;

                // 末尾除去
                outText = selectPositionText1.Remove((int)param4); //param4（開始位置）から最後まで削除

                return outText;
            }
            catch 
            {
                throw new Exception("末尾除去に失敗しました。");
            }
        }
    }

}