using System;
using System.Collections;
using System.Data;
using System.Collections.Generic;

namespace OutSystems.NssExecuteProcessing {

    //加工処理Id一覧
    public enum Process
        {
            SampleDeleteString,                 // 文字列削除処理（サンプル）
            SampleConcatString,                 // 文字列連結処理（サンプル）
            SubstringSelectColumn,              // 文字列抽出(列指定)
            ConcatColumnAndColumn,              // 文字列連結(列＋列)(列指定)
            ConcatColumnAndString,              // 文字列連結(列＋文字)(列指定)
            MappingOnlySelectColumn,            // マッピングのみ(列指定)
            MappingOnlySelectPosition,          // マッピングのみ(文字位置指定)
            InputFixedValue,                    // 固定値入力
            SubstringSelectPosition,            // 文字列抽出(文字位置指定)
            RemoveStringSelectColumn,           // 指定文字列除去(列指定)
            RemoveStringSelectPosition,         // 指定文字列除去(文字位置指定)
            RemoveFrontZeroSelectColumn,        // 前ゼロ除去(列指定)
            RemoveFrontZeroSelectPosition,      // 前ゼロ除去(文字位置指定)
            SubstringFrontSelectColumn,         // 指定文字より前から取得(列指定)
            SubstringFrontSelectPosition,       // 指定文字より前から取得(文字位置指定)
            SubstringBehindSelectColumn,        // 指定文字より後から取得(列指定)
            SubstringBehindSelectPosition,      // 指定文字より後から取得(文字位置指定)
            ConcatString_ColumnStringColumn,    // 文字列連結(列＋文字＋列)(列指定)
            ConcatString_ColumnStringString,    // 文字列連結(列＋文字＋文字)(列指定)
            RemoveEndStringSelectColumn,        // 末尾除去(列指定)
            RemoveEndStringSelectPosition,      // 末尾除去(文字位置指定)
            ConditionJudgment,                  // 条件判定(列指定)
            ConvertStringVpayment,              // 文字変換（Vpayment）(列指定)
            ConvertStringVpaymentOSL,           // 文字変換（Vpayment(OSL)）(列指定)
            ConvertStringNetrustBillingCode,    // 文字変換（ネットラスト　請求先コード）(列指定)
            ConvertStringNetrustPaymentMethod,  // 文字変換（ネットラスト　支払方法）(列指定)
            ConvertStringTryumph21,             // 文字変換（トライアンフ21）(列指定)
            JudgmentNumericAriba,               // 数値判定（Ariba(日東電工)）(列指定)

            Logic = 1111
        }

    public class ProcessFactory{

		//加工処理Idと処理クラスのマッピング定義
        Dictionary<Process,ProcessInterface> MethodDict = new Dictionary<Process,ProcessInterface>()
		{
            {Process.SampleDeleteString, new DeleteString()},
            {Process.SampleConcatString, new ConcatString()},
            {Process.SubstringSelectColumn, new SubstringSelectColumn()},
            {Process.ConcatColumnAndColumn, new ConcatColumnAndColumn()},
            {Process.ConcatColumnAndString, new ConcatColumnAndString()},
            {Process.MappingOnlySelectColumn, new MappingOnlySelectColumn()},
            {Process.MappingOnlySelectPosition, new MappingOnlySelectPosition()},
            {Process.InputFixedValue, new InputFixedValue()},
            {Process.SubstringSelectPosition, new SubstringSelectPosition()},
            {Process.RemoveStringSelectColumn, new RemoveStringSelectColumn()},
            {Process.RemoveStringSelectPosition, new RemoveStringSelectPosition()},
            {Process.RemoveFrontZeroSelectColumn, new RemoveFrontZeroSelectColumn()},
            {Process.RemoveFrontZeroSelectPosition, new RemoveFrontZeroSelectPosition()},
            {Process.SubstringFrontSelectColumn, new SubstringFrontSelectColumn()},
            {Process.SubstringFrontSelectPosition, new SubstringFrontSelectPosition()},
            {Process.SubstringBehindSelectColumn, new SubstringBehindSelectColumn()},
            {Process.SubstringBehindSelectPosition, new SubstringBehindSelectPosition()},
            {Process.ConcatString_ColumnStringColumn, new ConcatString_ColumnStringColumn()},
            {Process.ConcatString_ColumnStringString, new ConcatString_ColumnStringString()},
            {Process.RemoveEndStringSelectColumn, new RemoveEndStringSelectColumn()},
            {Process.RemoveEndStringSelectPosition, new RemoveEndStringSelectPosition()},
            {Process.ConditionJudgment, new ConditionJudgment()},
            {Process.ConvertStringVpayment, new ConvertStringVpayment()},
            {Process.ConvertStringVpaymentOSL, new ConvertStringVpaymentOSL()},
            {Process.ConvertStringNetrustBillingCode, new ConvertStringNetrustBillingCode()},
            {Process.ConvertStringNetrustPaymentMethod, new ConvertStringNetrustPaymentMethod()},
            {Process.ConvertStringTryumph21, new ConvertStringTryumph21()},
            {Process.JudgmentNumericAriba, new JudgmentNumericAriba()},
            {Process.Logic, new Logic()}
        };

		//引数で指定された加工処理Idと一致する処理メソッドをインスタンス化して返す
        public ProcessInterface create(Process str){
            return MethodDict[str];
        }
    }
}